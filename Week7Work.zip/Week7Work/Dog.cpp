/* Dog.cpp - Definition of functions for the Dog subclass
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    Lab, Part 2
 */


#include "Dog.h"
#include <iostream>

Dog::Dog(string theName, string theBreed): Animal{theName},breed{theBreed}
{
    cout<<"The Dog "<<getName()<<" of breed "<< getBreed()<<" has been created.."<<endl;

}

string Dog::getBreed() {
    return breed;
}

void Dog::setBreed(string theBreed) {

    breed = theBreed;
}


void Dog::makeNoise() {

    cout<<"The Dog "<<getName()<<" is barking."<<endl;
}

void Dog::showInfo() {
    cout<<"The Dog "<<getName()<<" of breed "<<getBreed()<<endl;
}