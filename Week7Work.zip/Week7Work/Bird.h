/* Bird.h - Header for Bird class
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    Lab, Part 2
 *
 * Description: Bird class that is a subclass of the Animal class that defines a Bird object
 *
 *    Functions:
 *       full constructor:
 *          Bird(string)

 *       void makeNoise()- returns string stating that the Bird is chirping
 *       void showInfo()- returns info of the Bird class
 *
 */

#ifndef BIRD_H
#define BIRD_H

#include <iostream>
#include "Animal.h"
using namespace std ;

class Bird : public Animal {

public:
    Bird(string);

    void makeNoise();
    void showInfo();

} ;

#endif
