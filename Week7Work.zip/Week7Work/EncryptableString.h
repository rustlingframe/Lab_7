/* EncryptableString.h -  a header file for EncryptableString class that is derived from the STL string class
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    HomeWork, Programming Project 6
 *
 * Description: A header that defines EncryptableString class
 *

 *    Functions:
 *       full constructor:
 *          EncryptableString(string)
 *
 *    void Encrypt()- encrypts' the string instance variable and displays the encryption
 *
 */

#ifndef ENCRYPTABLESTRING_H
#define ENCRYPTABLESTRING_H

#include <iostream>
using namespace std;
class EncryptableString:public string {

public:
    EncryptableString(std::string);
    void encrypt();

} ;

#endif
