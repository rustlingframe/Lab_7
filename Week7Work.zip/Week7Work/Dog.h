/* Dog.h - Header for the Dog class
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    Lab, Part 2
 *
 * Description: a class that is derived from the Animal class that defines a Dog object
 *
 *    Instance members:
 *    string breed- variable that holds that name of the breed of the dog object
 *
 *    Functions:
 *       full constructor:
 *          Dog(string)
 *       all getters and setters:
 *
 *          string getBreed()- returns the string breed
 *          void setBreed(string)- sets the breed instance variable to the argument string
 *
 *       void makeNoise()- returns string stating that the dog is barking
 *       void showInfo()- returns info of the Dog class
 *
 */

#ifndef DOG_H
#define DOG_H

#include <iostream>
#include "Animal.h"

using namespace std ;

class Dog : public Animal {

private:
    string breed;

public:
    Dog(string,string);

    string getBreed();
    void setBreed(string);
    void makeNoise();
    void showInfo();

} ;

#endif
