/* PString.cpp - Definition of functions for the PString class
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    HomeWork, Programming Project 5
 */

#include "PString.h"
#include <iostream>

using namespace std;

PString::PString(string theString) : string(theString){}

bool PString::isPalindrome() {

    PString defaultString = *this;

    for(int i = 0,length = defaultString.size();i<length;i++)
    {
        if(ispunct(defaultString[i]))
        {
            defaultString.erase(i--,1);

        }
        if(isspace(defaultString[i]))
        {
            defaultString.erase(i--,1);
        }
        if(isupper(defaultString[i]))
        {
            defaultString[i] = tolower(defaultString[i]);
        }

    }

    PString reversedCopy = defaultString;


    reverse(reversedCopy.begin(),reversedCopy.end());

    cout<<defaultString<<endl;
    cout<<reversedCopy<<endl;
    for(int i = 0; i < reversedCopy.size();i++ )
    {
        if(reversedCopy[i] != defaultString[i])
        {
            cout<<*this<<" is not a palidrome."<<endl;
            cout<<reversedCopy[i]<<i<<endl;
            return false;

        }
    }

    cout<<*this<<" is a palindrome"<<endl;

    return true;

}

int main()
{
    PString testString1("Chic");
    PString testString2("Book");
    PString testString3("Kayak");
    PString testString4("25 ABC 9cba52");
    PString testString5("Don't nod");
    PString testString6("Not even close!");
    PString testString7("A man, a plan, a canal -- Panama");


    testString1.isPalindrome();
    testString2.isPalindrome();
    testString3.isPalindrome();
    testString4.isPalindrome();
    testString5.isPalindrome();
    testString6.isPalindrome();
    testString7.isPalindrome();



}