/* Bird.cpp - Definition of functions for the Bird class
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    Lab, Part 2
 */


#include "Bird.h"
#include <iostream>

Bird::Bird(string theName): Animal{theName}
{
    cout<<"The Bird "<<getName()<<" has been created.."<<endl;

}

void Bird::makeNoise() {

    cout<<"The Bird "<<getName()<<" is chirping."<<endl;
}

void Bird::showInfo() {
    cout<<"The Bird "<<getName()<<endl;
}