/* Animal.cpp - Definition of functions for the Animal parent class
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    Lab, Part 2
 */

#include "Animal.h"
#include <iostream>

Animal::Animal(string theName): name{theName}
{
    cout<<"The Animal "<<getName()<<" has been created.."<<endl;

}

string Animal::getName() {
    return name;
}

void Animal::setName(string theName) {

    name = theName;
}

void Animal::sleep() {
    cout<<"The Animal "<<getName()<<" is asleep."<<endl;
}

void Animal::makeNoise() {

    cout<<"The Animal "<<getName()<<" is making noise."<<endl;
}

void Animal::showInfo() {
    cout<<"The Animal "<<getName()<<endl;
}