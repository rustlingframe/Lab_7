/* Lab7.cpp - Tester class that contains the main method of project 2
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    Lab, Part 2
 *
 * 1.What is/are the names of the base classes?
 * Animal
 * What is/are the names of the derived classes?
 * Bird Dog
 * Does Animal have a parent class?
 * No
 * Is the function showInfo() overridden? Is makeNoise? Is sleep?
 * showInfo()- overridden in the Bird and Dog class
 * makeNoise()- overridden in the Bird and Dog class
 * sleep()- not ovverrideen in either class all classes use base class function
 *
 * If the instance member name in the Animal class were made protected
 * (instead of private), would you need to use getters and setters in the showInfo
 * function of the child classes Bird and Dog?
 * No need to use setters and getters because a protected declaration means it can be accessed in its child classes
 *
 * What if the instance members were left private,
 * but the the access modifier to the Animal class in both child classes were made protected?
 * they would need to be accessed using the setters and getters since protected limits access like the private modifier
 *
 * Description: tester class that test the Animal class objects and objects of its derived classes
 *
 *    ALGORITHAM:
 *    1. Create Animal Object with argument "Oscar"
 *    2. call Animal objects showInfo function
 *    3. call Animal objects makeNoise function
 *    4. call Animal objects sleep function
 *
 *    5. Create Dog Object with argument "Inka","Mutt"
 *    6. call Dog objects showInfo function
 *    7. call Dog objects makeNoise function
 *    8. call Dog objects sleep function
 *
 *    9. Create Bird Object with argument "Tweety"
 *    10. call Bird objects showInfo function
 *    11. call Bird objects makeNoise function
 *    12. call Bird objects sleep function
 *
 *
 *
 */


#include <iostream>
#include "Animal.cpp"
#include "Dog.cpp"
#include "Bird.cpp"
using namespace std;

int main() {


    cout<<"*************************"<<endl;
    Animal oscar("Oscar");
    oscar.showInfo();
    oscar.makeNoise();
    oscar.sleep();
    cout<<"*************************"<<endl;
    cout<<"\n"<<endl;

    cout<<"*************************"<<endl;
    Dog inka("Inka","Mutt");
    inka.showInfo();
    inka.makeNoise();
    inka.sleep();
    cout<<"*************************"<<endl;
    cout<<"\n"<<endl;

    cout<<"*************************"<<endl;
    Bird tweety("Tweety");
    tweety.showInfo();
    tweety.makeNoise();
    tweety.sleep();
    cout<<"*************************"<<endl;
    cout<<"\n"<<endl;
}