/* PString.h -  a header file for PString class that is derived from the STL string class
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    HomeWork, Programming Project 5
 *
 * Description: A header that defines PString class
 *

 *    Functions:
 *       full constructor:
 *          PString(string)
 *
 *       bool isPalindrome()- checks if is a string is a palidrome
 *
 */

#ifndef PString_H
#define PString_H

#include <iostream>
using namespace std;
class PString:public string {

public:
    PString(string);
    bool isPalindrome();

} ;

#endif
