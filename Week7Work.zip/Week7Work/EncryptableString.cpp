/* EncryptableString.cpp - Definition of functions for the EncryptableString class
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    HomeWork, Programming Project 6
 */

#include "EncryptableString.h"
#include <iostream>
#include <vector>

using namespace std;

/* EncryptableString(string)- initializes a base class instance variable string to the theString
 */
EncryptableString::EncryptableString(string theString) : string(std::move(theString)){}

/* void Encrypt()- encrypts' the string instance variable and displays the encryption
 *
 * ALGORITHAM:
 * 1.intailize EncryptableString testString to this object
 * 2. for loop thriugh testString through each char
 * 3. IN FOR LOOP:intialize char to testString index position
 * 4. if char is '9' and set testString[i] to '0'
 * 5. if char is 'z' and set testString[i] to 'a' do same capital letters
 * 6. else testString[i] is set to ++ character
 * 7. OUTSIDE LOOP: display string
 *
 */
void EncryptableString::encrypt()
{
    EncryptableString testString = *this;

    for(int i = 0; i < testString.size();i++)
    {
        char character = testString[i];

        if(!ispunct(testString[i])&&!isspace(testString[i]))
        {
            if(character == '9')
            {
                testString[i] = '0';
            }
            if(character == 'z')
            {
                testString[i] = 'a';
            }
            if(character == 'Z')
            {
                testString[i] = 'A';
            }

            else
            {
                testString[i] = ++character;
            }

        }
    }

    cout<<"ENCRYPTED:\n"<<testString<<"\n"<<endl;
}

int main()
{
    vector<EncryptableString> vector1;
    vector1.reserve(10);



   for(int i = 0; i < 10; i++)
   {
       string input;
       cout<<"Enter the string: "<<endl;
       getline(cin,input);
       EncryptableString loopString(input);

       loopString.encrypt();


   }




}

