/* Animal.h - Header for parent(Animal) class of Dog,Bird classes
 * Author:     Alvaro Espinoza Merida
 * Module:     7
 * Project:    Lab, Part 2
 *
 * Description: A class that defines an Animal object
 *
 *    Instance members:
 *    string name- variable that holds that name of the animal object
 *
 *    Functions:
 *       full constructor:
 *          Animal(string)
 *       all getters and setters:
 *
 *          string getName()- returns the string name
 *          void setName(string)- sets the name instance variable to the argument string
 *
 *       void sleep()- returns string stating animal is asleep
 *       void makeNoise()- returns string stating animal is makign noise
 *       void showInfo()- returns info of the Animal class
 *
 */

#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
using namespace std ;

class Animal {

private:
    string name;

public:
    Animal(string);

   string getName();
   void setName(string);
   void sleep();
   void makeNoise();
   void showInfo();

} ;

#endif
